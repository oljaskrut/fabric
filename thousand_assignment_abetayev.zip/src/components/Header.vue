<template>
  <header class="container flex">
    <img
      alt="Vue logo"
      class="mr-2"
      src="@/assets/logo.svg"
      width="25"
      height="25"
    />
    <nav class="space-x-2">
      <RouterLink to="/" class="px-2 py-1 rounded-lg">Home</RouterLink>
    </nav>
  </header>
</template>
