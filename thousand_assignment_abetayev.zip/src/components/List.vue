<script setup lang="ts">
import { fetchPage } from "@/utils/fetchPage"
import type { MovieItem } from "@/utils/fetchPage"
import { ref } from "vue"
import { useInfiniteScroll } from "@vueuse/core"

const el = ref<HTMLElement | null>(null)
const data = ref<MovieItem[]>([])

let page = ref(0)

const { isLoading } = useInfiniteScroll(
  el,
  async () => {
    const moreData = await fetchPage(++page.value)
    data.value.push(...moreData)
  },
  { distance: 10 },
)
</script>

<template>
  <div v-if="data?.length === 0 && !isLoading"> Empty spaces... </div>
  <div
    class="grid gap-3 grid-cols-1 sm:gap-3 sm:grid-cols-2 md:grid-cols-3 lg:gap-4 xl:gap-6 lg:grid-cols-4 xl:grid-cols-5 h-screen overflow-y-auto mx-8 lg:mx-0"
    ref="el"
  >
    <div v-for="item in data" :key="item.id">
      <router-link
        :to="'/movie/' + item.id"
        class="group flex flex-col md:space-y-2 rounded-lg md:border relative bg-slate-900 shadow-md shadow-slate-800 h-full"
      >
        <img
          :src="
            'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/' +
            item.poster_path
          "
          class="flex rounded-t-lg bg-muted transition-colors object-cover aspect-1.5 w-full"
        />
        <div
          class="absolute top-1 left-1 flex rounded-full justify-center items-center border border-cyan-300 bg-slate-700 w-10 h-10 text-lg"
          >{{ item.vote_average }}</div
        >

        <div class="px-4 py-2 md:py-4">
          <div class="flex flex-col">
            <h2
              class="flex text-lg lg:text-2xl font-bold tracking-tight leading-6 md:my-2"
            >
              {{ item.title }}
            </h2>
            <span class="flex">
              {{ item.release_date }}
            </span>
          </div>
        </div>
      </router-link>
    </div>
    <h1 class="text-xl" v-if="isLoading">Loading...</h1>
  </div>
</template>
