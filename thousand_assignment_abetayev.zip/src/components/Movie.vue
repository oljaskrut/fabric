<script setup lang="ts">
import { fetchMovie } from "@/utils/fetchMovie"
import { useRoute } from "vue-router"

const { params } = useRoute()
const id = params.id as string
const item = await fetchMovie(id)
</script>

<template>
  <article
    v-if="item"
    class="group flex flex-col space-y-2 rounded-lg border shadow"
  >
    <div class="flex flex-col md:grid md:grid-cols-3">
      <img
        :src="
          'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/' +
          item.poster_path
        "
        class="col-span-1 flex rounded object-cover aspect-1.5 w-full"
        alt=""
      />
      <div class="p-4 col-span-2">
        <div class="mb-3"
          ><h2
            class="text-2xl md:text-3xl font-extrabold tracking-tight leading-6"
          >
            {{ item.title }}
          </h2>
          <span class="text-xl text-muted-foreground">{{ item.tagline }}</span>
        </div>

        <div class="grid grid-cols-2 text-md">
          <span
            >{{ item.status }}:
            {{ new Date(item.release_date).toLocaleDateString("en-US") }}</span
          >

          <span>User Score: {{ item.vote_average }}</span>

          <span>Popularity: {{ item.popularity }}</span>

          <span
            >Runtime: {{ ~~(item.runtime / 60) }}h
            {{ item.runtime % 60 }}m</span
          >

          <span
            >Budget:
            {{
              item.budget.toLocaleString("en-US", {
                style: "currency",
                currency: "USD",
                maximumFractionDigits: 0,
              })
            }}</span
          >
        </div>

        <div class="my-4 w-full h-[0.5px] bg-slate-400" />

        <p class="text-lg md:text-xl whitespace-pre-wrap indent-4">{{
          item.overview
        }}</p>

        <a
          :href="item.homepage"
          class="underline underline-offset-2 text-md text-slate-300"
          >{{
            item.homepage.split(".").reverse().slice(0, 2).reverse().join(".")
          }}</a
        >

        <div class="mt-3 text-slate-300">
          <div class="flex space-x-2">
            <span>Genres:</span>
            <div v-for="genre in item.genres">
              <span>{{ genre.name }}</span>
            </div>
          </div>

          <div class="flex space-x-2">
            <span>Countries:</span>
            <div v-for="country in item.production_countries">
              <span>{{ country.name }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </article>
  <div v-else> No such movie </div>
</template>
