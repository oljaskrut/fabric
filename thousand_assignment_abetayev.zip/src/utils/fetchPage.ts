import { TMDB_AUTH_KEY } from "./env"

export async function fetchPage(page = 1) {
  const res = await fetch(
    `https://api.themoviedb.org/3/movie/now_playing?language=en-US&page=${page}`,
    {
      headers: {
        Authorization: "Bearer " + TMDB_AUTH_KEY,
      },
    },
  )

  if (!res.ok) return []

  const { results } = (await res.json()) as Response

  return results
}

export interface Response {
  page: number
  results: MovieItem[]
  total_pages: number
  total_results: number
}

export interface MovieItem {
  adult: boolean
  backdrop_path: string
  genre_ids: number[]
  id: number
  original_language: string
  original_title: string
  overview: string
  popularity: number
  poster_path: string
  release_date: string
  title: string
  video: boolean
  vote_average: number
  vote_count: number
}
