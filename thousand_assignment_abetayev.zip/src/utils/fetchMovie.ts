import { TMDB_AUTH_KEY } from "./env"

export async function fetchMovie(id: string) {
  const res = await fetch(
    `https://api.themoviedb.org/3/movie/${id}?language=en-US`,
    {
      headers: {
        Authorization: "Bearer " + TMDB_AUTH_KEY,
      },
    },
  )

  if (!res.ok) return

  const item = (await res.json()) as {
    adult: boolean
    backdrop_path: string
    belongs_to_collection: any
    budget: number
    genres: {
      id: number
      name: string
    }[]
    homepage: string
    id: number
    imdb_id: string
    original_language: string
    original_title: string
    overview: string
    popularity: number
    poster_path: string
    production_companies: {
      id: number
      logo_path: string
      name: string
      origin_country: string
    }[]
    production_countries: {
      iso_3166_1: string
      name: string
    }[]
    release_date: string
    revenue: number
    runtime: number
    spoken_languages: {
      english_name: string
      iso_639_1: string
      name: string
    }[]
    status: string
    tagline: string
    title: string
    video: boolean
    vote_average: number
    vote_count: number
  }

  return item
}
