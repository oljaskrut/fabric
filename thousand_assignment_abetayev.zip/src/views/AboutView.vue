<script setup lang="ts">
import { Suspense } from "vue"
import Movie from "../components/Movie.vue"
</script>

<template>
  <Suspense>
    <Movie />
    <template #fallback> Loading... </template>
  </Suspense>
</template>
