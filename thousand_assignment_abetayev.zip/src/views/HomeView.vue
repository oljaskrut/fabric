<script setup lang="ts">
import { Suspense } from "vue"
import List from "../components/List.vue"
</script>

<template>
  <Suspense>
    <List />
    <template #fallback> Loading... </template>
  </Suspense>
</template>
