<script setup lang="ts">
import { RouterView } from "vue-router"
import Header from "./components/Header.vue"
</script>

<template>
  <main class="min-h-screen bg-background font-sans antialiased p-4">
    <div class="relative flex min-h-screen flex-col">
      <Header />
      <div class="container max-w-7xl mx-auto h-full md:pt-12">
        <RouterView />
      </div>
    </div>
  </main>
</template>
